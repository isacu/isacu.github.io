<?php
/**
 * Mail English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['mail_err_address_ns'] = 'Трябва да предоставите имейл адрес на получател.';
$_lang['mail_err_derive_getmailer'] = 'Опит да се извика абстрактна функция _getMailer() в modMail клас. Трябва да приложите тази функция в производна на modMail.';
$_lang['mail_err_attr_nv'] = '[[+attr]] не е валиден PHPMailer атрибут и ще бъде игнориран при изпълнението.';
$_lang['mail_err_unset_spec'] = 'modPHPMailer не поддържа изключване на конкретни адреси. Изолзвайте функцията нулиране/reset () за да изчистите всички получатели и добавете отново тези, на които искате да изпратите.';