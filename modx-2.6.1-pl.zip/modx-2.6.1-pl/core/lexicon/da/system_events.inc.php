<?php
/**
 * System Events English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Ryd';
$_lang['error_log'] = 'Fejlloggen';
$_lang['error_log_desc'] = 'Her er fejlloggen for MODX Revolution:';
$_lang['error_log_download'] = 'Download fejlloggen ([[+size]])';
$_lang['error_log_too_large'] = 'Fejlloggen i <em>[[+name]]</em> er for stor til at blive vist. Du kan downloade den ved at trykke på knappen nedenfor.';
$_lang['system_events'] = 'Systemhændelser';
$_lang['priority'] = 'Prioritet';